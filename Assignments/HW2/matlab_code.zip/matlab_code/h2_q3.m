data_1 = csvread('brca_reduced.csv');
Y_1 = data_1(:, 1);
X_1 = data_1(:, 2:end);

%a)
fprintf("OLS fit \n")
X_1 = [ones(size(Y_1)),X_1];
B_ols_1 = regress(Y_1,X_1);
MSE_ols_1 = mean((Y_1 - X_1*B_ols_1).^2);
fprintf("MSE for clean data = %f \n",MSE_ols_1);
norm_ols_1 = norm(B_ols_1, inf);
fprintf("l-inf norm for clean data = %f \n", norm_ols_1)


data_2 = csvread('brca_noisy.csv');
Y_2 = data_2(:, 1);
X_2 = data_2(:, 2:end);
X_2 = [ones(size(Y_2)),X_2];
B_ols_2 = regress(Y_2,X_2);
MSE_ols_2 = mean((Y_2 - X_2*B_ols_2).^2);
fprintf("MSE for noisy data = %f \n", MSE_ols_2)
norm_ols_2 = norm(B_ols_2, inf);
fprintf("l-inf norm for noisy data = %f \n",norm_ols_2)

disp(" ")
%b)
fprintf("Robust fit using huber loss \n")
X_1 = data_1(:, 2:end);
B_robust_1 = robustfit(X_1,Y_1, 'huber');
MSE_robust_1 = mean((Y_1 - X_1*B_robust_1(2:end) + B_robust_1(1)).^2);
fprintf("MSE for clean data= %f \n",MSE_robust_1)
norm_robost_1 = norm(B_robust_1, inf);
fprintf("l-inf norm for clean data = %f \n",norm_robost_1)

X_2 = data_1(:, 2:end);
B_robust_2 = robustfit(X_2,Y_2, 'huber');
MSE_robust_2 = mean((Y_2 - X_2*B_robust_2(2:end) + B_robust_2(1)).^2);
fprintf("MSE for noisy data = %f \n",MSE_robust_2)
norm_robost_2 = norm(B_robust_2, inf);
fprintf("l-inf norm for noisy data = %f \n",norm_robost_2)

disp(" ")
%c)

losses = ["cauchy", "talwar", "welsch"];
for i =1:length(losses)
    loss = losses(i);
    fprintf("Robust fit using %s loss \n", loss)
    B_robust_1 = robustfit(X_1,Y_1, loss);
    MSE_robust_1 = mean((Y_1 - X_1*B_robust_1(2:end) + B_robust_1(1)).^2);
    fprintf("MSE for clean data = %f \n",MSE_robust_1);
    norm_robost_1 = norm(B_robust_1, inf);
    fprintf("l-inf norm for clean data = %f \n",norm_robost_1);

    X_2 = data_1(:, 2:end);
    B_robust_2 = robustfit(X_2,Y_2, loss);
    MSE_robust_2 = mean((Y_2 - X_2*B_robust_2(2:end) + B_robust_2(1)).^2);
    fprintf("MSE for noisy data = %f \n",MSE_robust_2)
    norm_robost_2 = norm(B_robust_2, inf);
    fprintf("l-inf norm for noisy data = %f \n",norm_robost_2)
    disp(" ")
end



