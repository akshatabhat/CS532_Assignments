% Homework 2 - Question 1
data = readtable('polydata.csv');
Y = data.Var2;
Y_size = size(Y);


X_d1 = create_Matrix_X(data, 1);
B_ols_d1 = fitlm(X_d1, Y);

X_d2 = create_Matrix_X(data, 2);
B_ols_d2 = fitlm(X_d2, Y);

X_d3 = create_Matrix_X(data, 3);
B_ols_d3 = fitlm(X_d3, Y);

X_d4 = create_Matrix_X(data, 4);
B_ols_d4 = fitlm(X_d4, Y);

X_d5 = create_Matrix_X(data, 5);
B_ols_d5 = fitlm(X_d5, Y);

%b)Scatter plot

scatter(X_d1, Y)
hold on

myplot(X_d1, B_ols_d1.Coefficients.Estimate)
myplot(X_d1, B_ols_d2.Coefficients.Estimate)
myplot(X_d1, B_ols_d3.Coefficients.Estimate)
myplot(X_d1, B_ols_d4.Coefficients.Estimate)
myplot(X_d1, B_ols_d5.Coefficients.Estimate)

%c) Cross-validation

c = cvpartition(Y_size(1), 'KFold', 5);
for d=1:5
    X = create_Matrix_X(data, d);
    y = Y;
    cp = cvpartition(y,'k',5)
    X(cp.training(2))
    X(cp.test(2))
    regf=@(XTRAIN,ytrain,XTEST)(predfun(XTRAIN,ytrain,XTEST));
    cvMse = crossval('mse',X,y,'predfun',regf, "partition", cp)

end


function yfit = predfun(XTRAIN,ytrain,XTEST)
    B = fitlm(XTRAIN,ytrain);
    yfit = predict(B, XTEST);
end
function X = create_Matrix_X(data, d)
    Y = data.Var2;
    X = zeros(size(Y,1),d);
    for k = 1:d
        X(:, k) = data.Var1.^k;
    end
end

function myplot(X, B)
t = linspace(min(X),max(X));
plot(t, polyval(flipud(B), t))
end